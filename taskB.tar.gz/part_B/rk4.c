/*
 * rk4.c
 * Modified euler.c
 * modifications by Michael Soskind
 */
#include "integrator.h"

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

typedef int (*FuncPtr)(int n, double t, const double *x, double *Dx);

/* Integrator object for Forward Euler method */
struct integrator_t
{
  int n;		   	/* dimension of state vector */
  double dt;		  	/* time step */
  FuncPtr rhs;		      	/* right-hand-side of \dot x = f(x,t) */
};
  
/* "Constructor" */
Integrator *integrator_new(const int n, const double dt, FuncPtr rhs)
{
  Integrator *integrator = (Integrator *) malloc(sizeof(*integrator));
  assert(integrator);
  
  integrator->n = n;
  integrator->dt = dt;
  integrator->rhs = rhs;

  return integrator;
}

/* "Destructor" */
void integrator_free(Integrator *integrator)
{
  assert(integrator);
  free(integrator);
}

/* Stepper */
int integrator_step(Integrator *integrator, double t, double *x)
{
  assert(integrator);
  const int n = integrator->n;	/* Shorthand `n` for use
				   in-function */
  double fx[n];			/* NB: This is a VLA!! */
  double k[8];
  double fact = 1/6;

  for (int j = 0; j < 4; ++j){

  /* Bubble up any errors from RHS function */
    if (j == 1){
      t += t/n;
      *x += k[1]/2;
    }
    else if (j == 2){
      *x += (k[3]/2 -k[1]/2);
    }
    else if (j == 3){
      t += t/n;
      *x += k[5] - (k[3]/2 -k[1]/2);
    }

    int rhserr = integrator->rhs(n, t, x, fx);
    if (rhserr != 0)
    {
      return rhserr;
    }

    k[0] = integrator->dt * fx[0];
  
    /* Forward Euler algorithm for dx */
    for (int i = 0; i < n; ++i)
    {
      k[2*j+i] = fx[i];		// trying to allocate each k
      
      // accounting for multiplication factors in R-K algorithm
      if (j == 0 || j == 3){
        fact = 1/6;
      }
      else if (j == 1 || j == 2){
        fact = 1/3;
      } 
      // applying step, and returning another value for x, where
      // the final value is the full
      x[i] += integrator->dt * k[2*j+i] * fact;

      //printf("\n %d %f %f \n", 2*j+i, k[2*j+i], x[i]);

    }
  
  }

  /* Successful exit */
  return 0;
}

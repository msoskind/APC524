/*
 * ddo.c
 * Created by Michael Soskind
 */

/* Including libraries required for the program*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* Including the additional library for integration*/
#include "integrator.h"

/* Defining the useful variable PI */
#define PI 3.141599265358979;

/*
Omega defined as a global variable as described by Chris and
Prof Gabe on CampusWire
*/
double w;

/* 
Declaring the function name (if not done, C does not recognize the
function at the bottom. The function could be at the top, but I like
to see the function after the main file) 
*/

int rhs(int n, double t, const double *x, double *Dx)
{
	// Defining the newly calculated values as needed (w/o dt)
	Dx[0] = x[1];
	Dx[1] = (cos(w*t) - x[0] - 0.5*x[1]);

	// Return zero to make sure that the function does indeed work
	return 0;
}

int main(int argc, char* argv[])
{
	w = atof(argv[1]);	// convert frequency to float from arg 1
	int n = atol(argv[2]);	// convert num steps to int from arg 2	

	double tend = 6*PI;	// Defining the time to integrate over
	double dt = tend / n;	// Defining the step size
	double t = 0.0;		// Defining the initial time
	double xvals[2];	// Predefine the array xvals

	// Initialize and declare the Integrator file in this program
	Integrator *integrating_stuff = integrator_new(2, dt, rhs);

	for (int i = 0; i <= n; ++i)
	{
		// Printing the values and steps		
		printf("%15.8f %15.8f %15.8f\n", t, xvals[0], xvals[1]);
		
		// Defining the newly calculated values
		integrator_step(integrating_stuff, t, xvals);

		// Incrementing the time step				
		t += dt;
	}

	// Freeing the integrator just constructed 
	integrator_free(integrating_stuff);
	
	// Function needs to return an int, since that is how it is declared
	return 0;
}

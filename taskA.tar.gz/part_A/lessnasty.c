/*
 * less_nasty.c
 * Modified by Michael Soskind
 */

/* Including libraries required for the program*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14159265358979;

/* 
Declaring the function name (if not done, C does not recognize the
function at the bottom. The function could be at the top, but I like
to see the function after the main file) 
*/
void integrator (double w, int nsteps); 

// Defining global variables time, x, dx, and tend
double t = 0.0;		/* Declaring the initial time */
double x = 0.0;		/* Declaring the initial x value */
double dx = 0.0;	/* Initializing the step to be zero*/
double tend = 6*PI;	/* Defining the time to integrate over*/
// I chose to define these all as global to make it easy to change at the beginning
// of the code, and although not super modular, it allows for rapid changes in the
// initial conditions

int main(int argc, char* argv[])
{
	double w = atof(argv[1]);	// convert frequency to float from arg 1
	int nsteps = atol(argv[2]);	// convert num steps to int from arg 2

	integrator(w, nsteps);		// perform integrator on above values

	/* 
	Because the function does the initializations and calculations
	it contains all of the variabl initializations, as well as
	the controlled inputs, which are the number of steps and the
	coefficients of the cosine and constant terms 
	*/

	/* Function needs to return an int, since that is how it is declared */
	return 0;
}

void integrator (double w, int nsteps)  
{
	/* Defining the previously calculated values*/		
	double xold;
	double dxold;	
	double dt = tend / nsteps;	/* Defining the step size for a given number of steps*/
	for (int i = 0; i < nsteps; ++i)
	{
		/* Defining the previously calculated values*/		
		xold = x;
		dxold = dx;

		/* Defining the newly calculated values*/
		x += dt * dxold;
		dx += dt * (cos(w*t) - xold - 0.5*dxold);
		t += dt;

		/* Printing the time, size, and step-size each time*/
		printf("%15.8f %15.8f %15.8f\n", t, x, dx);
	}
	// I chose to go about this in this fashion, as Euler's method is most obviously done
	// in this way. Although it is much harder to change to an alternative routine.
	printf("\n");

	return;
}
